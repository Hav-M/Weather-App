import React, { useState, useEffect } from 'react';
import Loader from './Loader';

function App() {
  const [city, setCity] = useState('');
  const [weather, setWeather] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [suggestions, setSuggestions] = useState([]);
  const [darkMode, setDarkMode] = useState(false);

  // Toggle dark mode
  const toggleDarkMode = () => {
    const newDarkMode = !darkMode;
    setDarkMode(newDarkMode);
    localStorage.setItem('darkMode', newDarkMode ? 'enabled' : 'disabled');
  };

  // Apply dark mode class to the body
  useEffect(() => {
    const savedTheme = localStorage.getItem('darkMode');
    if (savedTheme === 'enabled') {
      setDarkMode(true);
      document.documentElement.classList.add('dark');
    } else {
      setDarkMode(false);
      document.documentElement.classList.remove('dark');
    }
  }, []);

  const fetchWeather = async () => {
    if (!city) {
      setError('Please enter a city');
      return;
    }

    setLoading(true);
    setError('');
    setWeather(null);

    try {
      const response = await fetch(`http://localhost:5000/weather?city=${city}`);
      const data = await response.json();
      if (response.ok) {
        setWeather(data);
      } else {
        setError(data.error || 'Failed to fetch weather data');
      }
    } catch (err) {
      setError('Failed to fetch weather data');
    } finally {
      setLoading(false);
    }
  };

  const fetchSuggestions = async (query) => {
    if (!query) {
      setSuggestions([]);
      return;
    }

    try {
      const response = await fetch(`http://localhost:5000/suggestions?query=${query}`);
      const data = await response.json();
      setSuggestions(data);
    } catch (err) {
      console.error('Failed to fetch suggestions:', err);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-500 to-purple-600 dark:from-gray-900 dark:to-gray-800 flex flex-col items-center justify-center p-4 transition-colors duration-300">
      {loading && <Loader />}
      {/* Theme Toggle Button */}
      <button
        onClick={toggleDarkMode}
        className="fixed top-4 right-4 p-2 bg-white dark:bg-gray-800 rounded-full shadow-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors duration-300"
      >
        {darkMode ? '🌞' : '🌙'}
      </button>

      <h1 className="text-4xl font-bold text-white mb-8">Weather App</h1>
      <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg w-full max-w-md transition-colors duration-300">
        <div className="flex flex-col space-y-4">
          <div className="relative">
            <input
              type="text"
              placeholder="Enter city"
              value={city}
              onChange={(e) => {
                setCity(e.target.value);
                fetchSuggestions(e.target.value);
              }}
              className="p-2 border border-gray-300 dark:border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-600 w-full bg-transparent dark:text-white"
            />
            {city && (
              <button
                onClick={() => {
                  setCity('');
                  setSuggestions([]);
                  setWeather(null);
                }}
                className="absolute right-2 top-2 text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300"
              >
                ✕
              </button>
            )}
          </div>{suggestions.length > 0 && (
            <div className="mt-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg shadow-lg max-h-40 overflow-y-auto">
              {suggestions.map((suggestion, index) => (
                <div
                  key={index}
                  onClick={() => {
                    setCity(`${suggestion.name}, ${suggestion.country}`);
                    setSuggestions([]);
                  }}
                  className="p-2 hover:bg-gray-100 dark:hover:bg-gray-600 cursor-pointer dark:text-white"
                >
                  {suggestion.name}, {suggestion.country}
                </div>
              ))}
            </div>
          )}

          <button
            onClick={fetchWeather}
            disabled={loading}
            className="p-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 transition duration-300 flex items-center justify-center"
          >
            Get Weather
          </button>
        </div>

        {error && (
          <p className="mt-4 text-red-500 text-center">{error}</p>
        )}

        {weather && (
          <div className="mt-6 text-center">
            <h2 className="text-2xl font-semibold dark:text-white">
              {weather.name}, {weather.sys.country}
            </h2>
            <img
              src={`http://openweathermap.org/img/wn/${weather.weather[0].icon}@2x.png`}
              alt={weather.weather[0].description}
              className="mx-auto my-4"
            />
            <p className="text-lg capitalize dark:text-white">
              {weather.weather[0].description}
            </p>
            <p className="text-gray-700 dark:text-gray-300">Temperature: {weather.main.temp}°C</p>
            <p className="text-gray-700 dark:text-gray-300">Humidity: {weather.main.humidity}%</p>
            <p className="text-gray-700 dark:text-gray-300">Wind Speed: {weather.wind.speed} m/s</p>
          </div>
        )}
      </div>

      <footer className="mt-8 text-white text-sm">
        <p>
          Powered by{' '}
          <a
            href="https://openweathermap.org"
            target="_blank"
            rel="noopener noreferrer"
            className="underline hover:text-blue-200"
          >
            OpenWeatherMap
          </a>
        </p>
      </footer>
    </div>
  );
}

export default App;