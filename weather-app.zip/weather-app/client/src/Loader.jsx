const Loader = () => {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 dark:bg-opacity-70 z-50">
        <div className="ivah-loader pop-up text-white">IVAH_M</div>
      </div>
    );
  };
  
  export default Loader;